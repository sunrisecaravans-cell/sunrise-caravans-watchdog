# Sunrise Caravans Lead Delivery Watchdog

Automated GitHub Actions workflow that runs daily at 8 AM Brisbane time to check for stuck website leads.

## Setup

1. Add 6 secrets in GitHub Settings
2. Workflow runs automatically each day
3. Get Telegram alerts if leads stuck

## Manual Test

Go to Actions → Lead Delivery Watchdog → Run workflow
