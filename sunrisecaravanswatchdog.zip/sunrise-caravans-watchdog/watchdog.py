#!/usr/bin/env python3
"""
Sunrise Caravans Lead Delivery Watchdog
Checks for stuck leads and sends alerts if any are found.
Never ends silently.
"""

import os
import sys
import json
import requests
from datetime import datetime, timezone
from supabase import create_client, Client

# Load credentials from environment
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_SECRET_KEY = os.getenv("SUPABASE_SECRET_KEY")
LOVABLE_API_KEY = os.getenv("LOVABLE_API_KEY")
LOVABLE_PROJECT_ID = os.getenv("LOVABLE_PROJECT_ID")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

def log(msg):
    """Log with timestamp"""
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{ts}] {msg}")

def check_stuck_leads():
    """Query Lovable for stuck leads"""
    log("STEP 1: Querying Lovable for stuck leads...")

    try:
        # Connect to Supabase (Lovable's database)
        supabase: Client = create_client(SUPABASE_URL, SUPABASE_SECRET_KEY)

        # Query for leads with no email_sent_at in the last 26 hours
        response = supabase.table("leads").select("id, first_name, last_name, email, phone, form_type, source_page, created_at, webhook_sent_at, email_sent_at").execute()

        leads = response.data if response.data else []

        # Filter for stuck leads
        stuck_leads = []
        for lead in leads:
            if lead.get("email_sent_at") is None:
                # Check if created in last 26 hours but more than 15 minutes ago
                created = lead.get("created_at")
                if created:
                    stuck_leads.append(lead)

        log(f"✅ Checked {len(leads)} leads, found {len(stuck_leads)} stuck")
        return stuck_leads

    except Exception as e:
        log(f"❌ Error querying leads: {str(e)}")
        send_error_alert(f"Failed to query Lovable database: {str(e)}")
        return None

def send_telegram_alert(stuck_leads):
    """Send Telegram alert about stuck leads"""
    if not stuck_leads:
        log("⏭️  STEP 2: No stuck leads, skipping Telegram alert")
        return True

    log(f"STEP 2: Sending Telegram alert for {len(stuck_leads)} stuck leads...")

    try:
        # Format lead list for message
        lead_list = "\n".join([
            f"• {lead['first_name']} {lead['last_name']} - {lead['phone']} ({lead['form_type']})"
            for lead in stuck_leads[:5]  # Show first 5
        ])

        if len(stuck_leads) > 5:
            lead_list += f"\n... and {len(stuck_leads) - 5} more"

        message = f"""🚨 ALERT: Website Leads Stuck Undelivered

{len(stuck_leads)} lead(s) failed to email:

{lead_list}

These leads did NOT reach your inbox. Check /admin or ring them back."""

        # Send via Telegram
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "Markdown"
        }

        response = requests.post(url, json=payload, timeout=10)

        if response.status_code == 200:
            log("✅ Telegram alert sent")
            return True
        else:
            log(f"❌ Telegram failed ({response.status_code}): {response.text}")
            return False

    except Exception as e:
        log(f"❌ Error sending Telegram: {str(e)}")
        return False

def send_error_alert(error_msg):
    """Send error alert via Telegram"""
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": f"🔴 Watchdog Error: {error_msg}"
        }
        requests.post(url, json=payload, timeout=10)
    except:
        pass

def write_heartbeat(num_checked, num_stuck, alert_sent):
    """Write heartbeat to Supabase"""
    log("STEP 3: Writing heartbeat to Supabase...")

    try:
        supabase: Client = create_client(SUPABASE_URL, SUPABASE_SECRET_KEY)

        detail = f"{num_checked} leads checked, {num_stuck} stuck, alert {'sent' if alert_sent else 'not needed'}"

        # Brisbane time
        now = datetime.now(timezone.utc)

        heartbeat = {
            "agent_name": "LEAD DELIVERY HEARTBEAT",
            "due_at": now.isoformat(),
            "verdict": "landed",
            "artifact_ref": "heartbeat",
            "artifact_at": now.isoformat(),
            "detail": detail,
            "checked_at": now.isoformat()
        }

        # Upsert heartbeat
        response = supabase.table("agent_runs").upsert(heartbeat).execute()

        log(f"✅ Heartbeat written: {detail}")
        return True

    except Exception as e:
        log(f"❌ Error writing heartbeat: {str(e)}")
        send_error_alert(f"Failed to write heartbeat: {str(e)}")
        return False

def main():
    """Run the watchdog"""
    log("=" * 60)
    log("LEAD DELIVERY WATCHDOG - STARTING")
    log("=" * 60)

    # Validate credentials
    if not all([SUPABASE_URL, SUPABASE_SECRET_KEY, LOVABLE_API_KEY, TELEGRAM_BOT_TOKEN]):
        log("❌ FATAL: Missing required credentials")
        sys.exit(1)

    # Check for stuck leads
    stuck_leads = check_stuck_leads()
    if stuck_leads is None:
        log("❌ Watchdog failed - could not query database")
        sys.exit(1)

    num_checked = len(stuck_leads) if stuck_leads else 0
    num_stuck = len([l for l in stuck_leads if l.get("email_sent_at") is None]) if stuck_leads else 0

    # Send alert if needed
    alert_sent = send_telegram_alert(stuck_leads) if stuck_leads else False

    # Write heartbeat (this is CRITICAL - never skip)
    write_heartbeat(num_checked, num_stuck, alert_sent)

    log("=" * 60)
    log("LEAD DELIVERY WATCHDOG - COMPLETE")
    log("=" * 60)

    sys.exit(0)

if __name__ == "__main__":
    main()
